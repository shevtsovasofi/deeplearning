import os
# тоже появилась ош 401, поэтому откличили все токены из окружения
for k in ("HUGGINGFACE_HUB_TOKEN", "HUGGINGFACE_API_TOKEN", "HF_TOKEN"):
    os.environ.pop(k, None)

import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss

#загружаем и чекаем наш цсв
def load_data_from_csv(csv_file: str):
    """Загрузить данные из CSV файла и подготовить для индексации FAISS."""
    df = pd.read_csv(csv_file)

    required_cols = {"id", "text"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"В файле {csv_file} нет обязательных колонок: {', '.join(missing)}")

# загружаем предобученный энкодер, если с первым не ок, то берем второй
    try:
        model = SentenceTransformer("all-MiniLM-L6-v2")
    except Exception:
        model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

    texts = df["text"].astype(str).tolist()

# создаем эмбеддинги
    embeddings = model.encode(texts, show_progress_bar=True, normalize_embeddings=False)
    embeddings = np.asarray(embeddings, dtype="float32")

    ids = df["id"].to_numpy()

    return embeddings, ids, df, model

# построение индекса faiss
def build_faiss_index(embeddings: np.ndarray):
    """Построить индекс FAISS из векторов-эмбеддингов под косинусное сходство (IP по L2-нормированным векторам)."""
    if embeddings.dtype != np.float32:
        embeddings = embeddings.astype("float32")

# нормализуем векторы для косинусного сходства
    faiss.normalize_L2(embeddings)

# получаем косинусное сходство
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    print("\n=== SUCCESSFULLY BUILT INDEX ===")
    print(f"Vectors: {index.ntotal}, dim: {dim}")
    return index

#поиск
from typing import Optional

def search_similar_vectors(index, query_vector: np.ndarray, k: int = 5, ids=None, original_df: Optional[pd.DataFrame] = None):
    """Поиск похожих векторов в индексе FAISS (cosine similarity)."""
    if query_vector.ndim == 1:
        query_vector = query_vector[None, :]

    query_vector = query_vector.astype("float32")
    faiss.normalize_L2(query_vector)

    similarities, indices = index.search(query_vector, k)

    results = []
    for rank, (sim, idx) in enumerate(zip(similarities[0], indices[0]), start=1):
        if idx == -1:
            continue
        item = {"rank": rank, "similarity": float(sim), "index": int(idx)}
        if ids is not None and len(ids) > idx:
            item["id"] = ids[idx]
        if original_df is not None:
            row = original_df.iloc[idx].to_dict()
            item["data"] = row
        results.append(item)
    return results

if __name__ == "__main__":
    csv_file = "data.csv"

    embeddings, ids, df, model = load_data_from_csv(csv_file)

    index = build_faiss_index(embeddings)

    search_query = input("\nВведите слово или фразу для поиска: ").strip()
    if not search_query:
        raise SystemExit("Пустой запрос.")

    query_embedding = model.encode([search_query], normalize_embeddings=False)
    query_embedding = np.asarray(query_embedding, dtype="float32")

    results = search_similar_vectors(index, query_embedding, k=3, ids=ids, original_df=df)

    print(f"\nТоп-3 для запроса '{search_query}':")
    for r in results:
        data = r.get("data", {})
        _id = data.get("id", r.get("id", "—"))
        date = data.get("date", "—")
        text = data.get("text", "")
        print(f"{r['rank']}. ID: {_id}, Дата: {date}")
        print(f"   Текст: {text}")
        print(f"   Сходство: {r['similarity']:.4f}\n")
