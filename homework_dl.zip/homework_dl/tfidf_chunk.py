import re, argparse
from typing import List, Tuple, Dict
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

CHUNK_SIZE = 400
OVERLAP = 60

def normalize(s: str) -> str:
    s = str(s).lower()
    s = re.sub(r"http\S+|www\.\S+", " ", s)
    s = re.sub(r"[^\w\s\-ёЁ]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = OVERLAP) -> List[str]:
    if chunk_size <= 0:
        return [text]
    text = text or ""
    chunks, n = [], len(text)
    start = 0
    while start < n:
        end = min(start + chunk_size, n)
        chunks.append(text[start:end])
        if end == n:
            break
        start = max(0, end - overlap)
    return chunks

def build_chunked(df: pd.DataFrame, chunk_size: int = CHUNK_SIZE, overlap: int = OVERLAP) -> Tuple[List[str], List[int]]:
    all_chunks, owners = [], []
    for i, row in df.iterrows():
        txt = normalize(row["text"])
        for ch in chunk_text(txt, chunk_size, overlap):
            all_chunks.append(ch)
            owners.append(i)
    return all_chunks, owners

def load_df(csv_file: str) -> pd.DataFrame:
    df = pd.read_csv(csv_file)
    required = {"id", "text"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"В {csv_file} нет колонок: {', '.join(missing)}")
    return df

class TfidfSearcher:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            ngram_range=(1,2),
            min_df=2,
            token_pattern=r"(?u)\b[\wёЁ-]{2,}\b"
        )
        self.matrix = None
        self.owners: List[int] = []

    def fit(self, chunks: List[str], owners: List[int]):
        self.matrix = self.vectorizer.fit_transform(chunks)
        self.owners = owners

    def search(self, query: str, k: int = 5):
        q = normalize(query)
        qv = self.vectorizer.transform([q])
        sims = cosine_similarity(qv, self.matrix)[0]  # по чанкам

        # агрегируем максимум по документам (doc_idx)
        best: Dict[int, Tuple[float, int]] = {}
        for ch_idx, sc in enumerate(sims):
            doc_idx = self.owners[ch_idx]
            if (doc_idx not in best) or (sc > best[doc_idx][0]):
                best[doc_idx] = (float(sc), int(ch_idx))

        ranked = sorted(((doc, sc, ch) for doc, (sc, ch) in best.items()), key=lambda x: -x[1])[:k]
        return ranked

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data.csv")
    ap.add_argument("--topk", type=int, default=3)
    ap.add_argument("--chunk-size", type=int, default=CHUNK_SIZE)
    ap.add_argument("--chunk-overlap", type=int, default=OVERLAP)
    args = ap.parse_args()

    df = load_df(args.data)
    chunks, owners = build_chunked(df, args.chunk_size, args.chunk_overlap)

    tf = TfidfSearcher()
    tf.fit(chunks, owners)

    q = input("\nВведите слово для поиска: ").strip()
    if not q:
        raise SystemExit("Пустой запрос.")

    results = tf.search(q, k=args.topk)

    print(f"\nТоп-{args.topk} (TF-IDF, с чанкингом) для запроса '{q}':")
    for rank, (doc_idx, sc, ch_idx) in enumerate(results, 1):
        row = df.iloc[doc_idx]
        print(f"{rank}. ID: {row.get('id','—')}  Дата: {row.get('date','—')}")
        print(f"   Текст: {row.get('text','')}")
        print(f"   Сходство: {sc:.8f}\n")
# для запуска:
# python3 tfidf_chunk.py --data data.csv --topk 5 --chunk-size 400 --chunk-overlap 60
