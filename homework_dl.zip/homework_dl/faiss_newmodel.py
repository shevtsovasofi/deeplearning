import os, re, argparse, tempfile, pathlib
from typing import Optional, List, Tuple, Dict

# опять защита от 401 хф и изоляция кэша 
for k in ("HUGGINGFACE_HUB_TOKEN", "HUGGINGFACE_API_TOKEN", "HF_TOKEN"):
    os.environ.pop(k, None)
_iso = os.path.join(tempfile.gettempdir(), "hf_noauth_cache")
pathlib.Path(_iso).mkdir(parents=True, exist_ok=True)
os.environ["HUGGINGFACE_HUB_CACHE"] = _iso
os.environ["TRANSFORMERS_CACHE"] = os.path.join(_iso, "transformers")
os.environ["HF_HOME"] = _iso
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss

# предобработка и чанкинг 
def normalize(s: str) -> str:
    s = str(s).lower()
    s = re.sub(r"http\S+|www\.\S+", " ", s)
    s = re.sub(r"[^\w\s\-ёЁ]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def chunk_text(text: str, chunk_size: int, overlap: int) -> List[Tuple[str,int,int]]:
    """Возвращает [(chunk_text, start, end), ...] по нормализованному тексту"""
    if chunk_size <= 0:
        t = text or ""
        return [(t, 0, len(t))]
    text = text or ""
    chunks, n = [], len(text)
    start = 0
    while start < n:
        end = min(start + chunk_size, n)
        chunks.append((text[start:end], start, end))
        if end == n:
            break
        start = max(0, end - overlap)
    return chunks

def build_chunked(df: pd.DataFrame, chunk_size: int, overlap: int):
    """Возвращает списки: chunks_text, owners(doc_idx), offsets[(s,e)]"""
    chunks, owners, offsets = [], [], []
    for i, row in df.iterrows():
        txt_norm = normalize(row["text"])
        for ch, s, e in chunk_text(txt_norm, chunk_size, overlap):
            chunks.append(ch); owners.append(i); offsets.append((s, e))
    return chunks, owners, offsets

# выбор модели и корректные префиксы 
def needs_e5_prefix(name: str) -> bool:
    name = name.lower()
    return "e5" in name or "gte" in name 

def needs_bge_prefix(name: str) -> bool:
    name = name.lower()
    return "bge" in name

def encode_docs(model: SentenceTransformer, texts: List[str], model_name: str):
    if needs_e5_prefix(model_name) or needs_bge_prefix(model_name):
        texts = [f"passage: {t}" for t in texts]
    emb = model.encode(texts, show_progress_bar=True, normalize_embeddings=False)
    return np.asarray(emb, dtype="float32")

def encode_query(model: SentenceTransformer, q: str, model_name: str):
    if needs_e5_prefix(model_name) or needs_bge_prefix(model_name):
        q = f"query: {q}"
    emb = model.encode([q], normalize_embeddings=False)
    return np.asarray(emb, dtype="float32")

# faiss
def build_faiss_index(embeddings: np.ndarray):
    if embeddings.dtype != np.float32:
        embeddings = embeddings.astype("float32")
# L2-нормализация - Inner Product равно косинусное сходство 
    faiss.normalize_L2(embeddings)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    print("\n=== SUCCESSFULLY BUILT INDEX ===")
    print(f"Vectors: {index.ntotal}, dim: {dim}")
    return index

def search_similar_vectors(index, query_vector: np.ndarray, k: int,
                           owners: List[int], offsets: List[Tuple[int,int]],
                           df: Optional[pd.DataFrame] = None):
    if query_vector.ndim == 1:
        query_vector = query_vector[None, :]
    query_vector = query_vector.astype("float32")
    faiss.normalize_L2(query_vector)

    sims, idxs = index.search(query_vector, k=max(k, 50)) 
    sims, idxs = sims[0], idxs[0]

# агрегируем до уровня документа
    best: Dict[int, Tuple[float, int]] = {}  # doc_idx -> (score, chunk_idx)
    for sc, ch_idx in zip(sims, idxs):
        if ch_idx == -1:
            continue
        doc_idx = owners[ch_idx]
        if (doc_idx not in best) or (sc > best[doc_idx][0]):
            best[doc_idx] = (float(sc), int(ch_idx))

    ranked = sorted(((doc, sc, ch) for doc, (sc, ch) in best.items()), key=lambda x: -x[1])[:k]

    results = []
    for rank, (doc_idx, sc, ch_idx) in enumerate(ranked, 1):
        item = {
            "rank": rank,
            "similarity": sc,
            "doc_idx": int(doc_idx),
            "chunk_idx": int(ch_idx),
        }
        if df is not None:
            row = df.iloc[doc_idx].to_dict()
            item["data"] = row
            orig = str(df.iloc[doc_idx]["text"])
            s, e = offsets[ch_idx]
            snippet = orig[s:e]
            item["snippet"] = snippet
        results.append(item)
    return results

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data.csv")
    ap.add_argument("--model", default="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
                    help="Напр.: sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2 | intfloat/multilingual-e5-base | BAAI/bge-m3 | thenlper/gte-base")
    ap.add_argument("--topk", type=int, default=5)
    ap.add_argument("--chunk-size", type=int, default=400)
    ap.add_argument("--chunk-overlap", type=int, default=60)
    args = ap.parse_args()

# 1 данные
    df = pd.read_csv(args.data)
    required = {"id", "text"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"В {args.data} нет колонок: {', '.join(missing)}")

# 2 чанкинг
    chunks, owners, offsets = build_chunked(df, args.chunk_size, args.chunk_overlap)

# 3 модель
    try:
        model = SentenceTransformer(args.model)
    except Exception:
# поддержка коротких алиасов без префикса
        model = SentenceTransformer(args.model if "/" in args.model else f"sentence-transformers/{args.model}")

# 4 эмбеддинги доков -с учётом префиксов для e5/bge/gte
    embeddings = encode_docs(model, chunks, args.model)
    index = build_faiss_index(embeddings)

# 5 запрос
    q = input("\nВведите слово или фразу для поиска: ").strip()
    if not q:
        raise SystemExit("Пустой запрос.")
    q_norm = normalize(q)
    q_emb = encode_query(model, q_norm, args.model)

# 6 поиск
    results = search_similar_vectors(index, q_emb, k=args.topk, owners=owners, offsets=offsets, df=df)

    print(f"\nТоп-{args.topk} (FAISS, модель: {args.model}) для запроса '{q}':")
    for r in results:
        d = r.get("data", {})
        print(f"{r['rank']}. ID: {d.get('id','—')}  Дата: {d.get('date','—')}")
        print(f"   Сходство: {r['similarity']:.4f}")
        if "snippet" in r:
            sn = r["snippet"]
            print(f"   Фрагмент: {sn[:300]}{'...' if len(sn)>300 else ''}\n")
        else:
            print(f"   Текст: {d.get('text','')[:300]}\n")

if __name__ == "__main__":
    main()

"""
запуск с разными вариантами моделей: 
python3 faiss_newmodel.py --data data.csv --model "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
python3 faiss_newmodel.py --data data.csv --model "intfloat/multilingual-e5-base"
python3 faiss_newmodel.py --data data.csv --model "BAAI/bge-m3"
python3 faiss_newmodel.py --data data.csv --model "sentence-transformers/all-MiniLM-L6-v2"
"""