#  строит оба индекса с одинаковым чанкингом и сравнивает выдачу
import os, re, tempfile, pathlib
import pandas as pd
import numpy as np
from typing import List, Tuple, Dict

# тоже отключаем, чтобы не было ошибки 401
for k in ("HUGGINGFACE_HUB_TOKEN", "HUGGINGFACE_API_TOKEN", "HF_TOKEN"):
    os.environ.pop(k, None)
_iso = os.path.join(tempfile.gettempdir(), "hf_noauth_cache")
pathlib.Path(_iso).mkdir(parents=True, exist_ok=True)
os.environ["HUGGINGFACE_HUB_CACHE"] = _iso
os.environ["TRANSFORMERS_CACHE"] = os.path.join(_iso, "transformers")
os.environ["HF_HOME"] = _iso
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

import faiss
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def normalize(s: str) -> str:
    s = str(s).lower()
    s = re.sub(r"http\S+|www\.\S+", " ", s)
    s = re.sub(r"[^\w\s\-ёЁ]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def chunk_text(text: str, chunk_size: int = 400, overlap: int = 60) -> List[str]:
    if chunk_size <= 0:
        return [text]
    text = text or ""
    chunks, n = [], len(text)
    start = 0
    while start < n:
        end = min(start + chunk_size, n)
        chunks.append(text[start:end])
        if end == n:
            break
        start = max(0, end - overlap)
    return chunks

def build_chunked(df: pd.DataFrame, chunk_size: int, overlap: int):
    chunks, owners = [], []
    for i, row in df.iterrows():
        for ch in chunk_text(normalize(row["text"]), chunk_size, overlap):
            chunks.append(ch); owners.append(i)
    return chunks, owners

def build_tfidf(chunks):
    vec = TfidfVectorizer(ngram_range=(1,2), min_df=2, token_pattern=r"(?u)\b[\wёЁ-]{2,}\b")
    X = vec.fit_transform(chunks)
    return vec, X

def tfidf_search(vec, X, owners, q, k=5):
    qv = vec.transform([normalize(q)])
    sims = cosine_similarity(qv, X)[0]
    best = {}
    for i, sc in enumerate(sims):
        doc = owners[i]
        if (doc not in best) or (sc > best[doc][0]):
            best[doc] = (float(sc), i)
    return sorted(((d, sc, ch) for d,(sc,ch) in best.items()), key=lambda x: -x[1])[:k]

def build_faiss(mdl, chunks):
    emb = mdl.encode(chunks, show_progress_bar=True, normalize_embeddings=False)
    emb = np.asarray(emb, dtype="float32"); faiss.normalize_L2(emb)
    idx = faiss.IndexFlatIP(emb.shape[1]); idx.add(emb)
    return idx, emb

def faiss_search(idx, mdl, owners, q, k=5):
    qv = mdl.encode([normalize(q)], normalize_embeddings=False)
    qv = np.asarray(qv, dtype="float32"); faiss.normalize_L2(qv)
    sims, ids = idx.search(qv, k=max(k,50)); sims, ids = sims[0], ids[0]
    best = {}
    for sc, i in zip(sims, ids):
        if i == -1: continue
        d = owners[i]
        if (d not in best) or (sc > best[d][0]): best[d] = (float(sc), i)
    return sorted(((d, sc, ch) for d,(sc,ch) in best.items()), key=lambda x: -x[1])[:k]

if __name__ == "__main__":
    df = pd.read_csv("data.csv")
    chunks, owners = build_chunked(df, 400, 60)

    vec, X = build_tfidf(chunks)
    mdl = SentenceTransformer("sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
    fidx, _ = build_faiss(mdl, chunks)

    q = input("Запрос: ").strip()
    tf = tfidf_search(vec, X, owners, q, k=5)
    fa = faiss_search(fidx, mdl, owners, q, k=5)

    print("\nTF-IDF:")
    for r,(doc,sc,ch) in enumerate(tf,1):
        row = df.iloc[doc]
        print(f"{r}. {row.get('id','—')}  {row.get('date','—')}  sc={sc:.4f}")
        print("   ", row.get("text","")[:140])

    print("\nFAISS/SBERT:")
    for r,(doc,sc,ch) in enumerate(fa,1):
        row = df.iloc[doc]
        print(f"{r}. {row.get('id','—')}  {row.get('date','—')}  sc={sc:.4f}")
        print("   ", row.get("text","")[:140])
