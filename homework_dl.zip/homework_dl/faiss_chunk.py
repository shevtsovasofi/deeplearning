import os, re, argparse, tempfile, pathlib
from typing import Optional, List, Tuple, Dict

#возникала оргибка 401, пришлось изолировать кэщ хф 
for k in ("HUGGINGFACE_HUB_TOKEN", "HUGGINGFACE_API_TOKEN", "HF_TOKEN"):
    os.environ.pop(k, None)
_iso = os.path.join(tempfile.gettempdir(), "hf_noauth_cache")
pathlib.Path(_iso).mkdir(parents=True, exist_ok=True)
os.environ["HUGGINGFACE_HUB_CACHE"] = _iso
os.environ["TRANSFORMERS_CACHE"] = os.path.join(_iso, "transformers")
os.environ["HF_HOME"] = _iso
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss

# параметры чанкинга 
CHUNK_SIZE = 400
OVERLAP = 60

def normalize(s: str) -> str:
    s = str(s).lower()
    s = re.sub(r"http\S+|www\.\S+", " ", s)
    s = re.sub(r"[^\w\s\-ёЁ]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = OVERLAP) -> List[str]:
    if chunk_size <= 0:
        return [text]
    text = text or ""
    chunks, n = [], len(text)
    start = 0
    while start < n:
        end = min(start + chunk_size, n)
        chunks.append(text[start:end])
        if end == n:
            break
        start = max(0, end - overlap)
    return chunks

def build_chunked(df: pd.DataFrame, chunk_size: int = CHUNK_SIZE, overlap: int = OVERLAP) -> Tuple[List[str], List[int]]:
    all_chunks, owners = [], []
    for i, row in df.iterrows():
        txt = normalize(row["text"])
        for ch in chunk_text(txt, chunk_size, overlap):
            all_chunks.append(ch)
            owners.append(i) 
    return all_chunks, owners

def load_df(csv_file: str) -> pd.DataFrame:
    df = pd.read_csv(csv_file)
    required = {"id", "text"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"В {csv_file} нет колонок: {', '.join(missing)}")
    return df

def build_faiss_index(embeddings: np.ndarray):
    if embeddings.dtype != np.float32:
        embeddings = embeddings.astype("float32")
    faiss.normalize_L2(embeddings)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    print("\n=== SUCCESSFULLY BUILT INDEX ===")
    print(f"Vectors: {index.ntotal}, dim: {dim}")
    return index

def search_similar_vectors(index, query_vector: np.ndarray, k: int,
                           owners: List[int], df: Optional[pd.DataFrame] = None):
    if query_vector.ndim == 1:
        query_vector = query_vector[None, :]
    query_vector = query_vector.astype("float32")
    faiss.normalize_L2(query_vector)

    # берём побольше кандидатов, затем агрегируем до документа
    sims, idxs = index.search(query_vector, k=max(k, 50))
    sims, idxs = sims[0], idxs[0]

    best: Dict[int, Tuple[float, int]] = {} 
    for sc, ch_idx in zip(sims, idxs):
        if ch_idx == -1:
            continue
        doc_idx = owners[ch_idx]
        if (doc_idx not in best) or (sc > best[doc_idx][0]):
            best[doc_idx] = (float(sc), int(ch_idx))

    ranked = sorted(((doc, sc, ch) for doc, (sc, ch) in best.items()), key=lambda x: -x[1])[:k]

    results = []
    for rank, (doc_idx, sc, ch_idx) in enumerate(ranked, 1):
        item = {"rank": rank, "similarity": sc, "doc_idx": int(doc_idx), "chunk_idx": int(ch_idx)}
        if df is not None:
            item["data"] = df.iloc[doc_idx].to_dict()
        results.append(item)
    return results

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data.csv")
    ap.add_argument("--model", default="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
                    help="Напр.: sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
    ap.add_argument("--topk", type=int, default=3)
    ap.add_argument("--chunk-size", type=int, default=CHUNK_SIZE)
    ap.add_argument("--chunk-overlap", type=int, default=OVERLAP)
    args = ap.parse_args()

    # загрузка данных
    df = load_df(args.data)

    # чанкинг
    chunks, owners = build_chunked(df, args.chunk_size, args.chunk_overlap)

    # модель
    try:
        model = SentenceTransformer(args.model)
    except Exception:
        model = SentenceTransformer(args.model if "/" in args.model else f"sentence-transformers/{args.model}")

    # эмбеддинги по чанкам
    embeddings = model.encode(chunks, show_progress_bar=True, normalize_embeddings=False)
    embeddings = np.asarray(embeddings, dtype="float32")

    # индекс
    index = build_faiss_index(embeddings)

    # запрос
    q = input("\nВведите слово или фразу для поиска: ").strip()
    if not q:
        raise SystemExit("Пустой запрос.")
    q_emb = model.encode([normalize(q)], normalize_embeddings=False)
    q_emb = np.asarray(q_emb, dtype="float32")

    # поиск (агрегация по документу)
    results = search_similar_vectors(index, q_emb, k=args.topk, owners=owners, df=df)

    print(f"\nТоп-{args.topk} (FAISS/SBERT, с чанкингом) для запроса '{q}':")
    for r in results:
        d = r.get("data", {})
        print(f"{r['rank']}. ID: {d.get('id','—')}  Дата: {d.get('date','—')}")
        print(f"   Текст: {d.get('text','')}")
        print(f"   Сходство: {r['similarity']:.4f}\n")
